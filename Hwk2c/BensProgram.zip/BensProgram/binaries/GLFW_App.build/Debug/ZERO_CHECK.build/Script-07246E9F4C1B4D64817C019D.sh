#!/bin/sh
make -C /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/Hwk2c/BensProgram/binaries -f /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/Hwk2c/BensProgram/binaries/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
