#!/bin/sh
make -C /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/Hwk2c/BensProgram/binaries -f /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/Hwk2c/BensProgram/binaries/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
