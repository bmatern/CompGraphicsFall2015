#!/bin/sh
make -C /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/GLBasicTest/NewBasicTest/lib/glfw/src/glfw-build -f /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/GLBasicTest/NewBasicTest/lib/glfw/src/glfw-build/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
