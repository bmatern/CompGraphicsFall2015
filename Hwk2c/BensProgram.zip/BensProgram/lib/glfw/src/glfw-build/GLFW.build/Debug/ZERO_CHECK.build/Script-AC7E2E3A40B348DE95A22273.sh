#!/bin/sh
make -C /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/GLBasicTest/NewBasicTest/lib/glfw/src/glfw-build -f /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/GLBasicTest/NewBasicTest/lib/glfw/src/glfw-build/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
