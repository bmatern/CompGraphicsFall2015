#!/bin/sh
make -C /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/GLBasicTest/NewBasicTest/lib/glfw/src/glfw-build -f /Users/bmatern/school/Fall2015/CompGraphics/CompGraphicsFall2015/GLBasicTest/NewBasicTest/lib/glfw/src/glfw-build/CMakeScripts/install_postBuildPhase.make$CONFIGURATION all
